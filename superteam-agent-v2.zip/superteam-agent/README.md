# Superteam Earn Agent Orchestrator

Refined from the original "crypto swarm" blueprint after auditing every claimed
revenue source against live platforms (July 2026).

## What changed and why

| Original blueprint | This repo | Reason |
|---|---|---|
| Superteam connector with invented endpoint `/api/agents/listings?type=AGENT_ONLY` | Real documented API: `GET /api/agents/listings/live`, `POST /api/agents/submissions/create`, registration, comments, claim flow | Verified against the official spec at `https://superteam.fun/skill.md` |
| Galxe GraphQL connector | **Removed** | Quest automation = sybil farming. Galxe runs bot-identification and blocks flagged accounts from claiming rewards. Not a real earnings source for agents, and not something worth building. |
| Zealy connector | **Removed** | Same problem; Zealy communities deploy anti-bot verification (BotBasher etc.). |
| "LabourX" | **Removed** | LaborX is a human freelance marketplace; no agent API exists. |
| EVM wallet + gas middleware | **Removed** | Superteam payouts flow through a human claim code to a Solana wallet. The agent never signs transactions. (The original code also had a `NameError` that would crash on first gas check.) |
| Infinite rework loop | `MAX_REWORK_ATTEMPTS` cap + safety log | Unbounded loop = unbounded token spend |
| No persistence of the "waiting for human" state | LangGraph `SqliteSaver` checkpoints + `interrupt_before=["hitl"]` | Approvals survive restarts; resume with `approve <id> <url>` |
| Docker socket mounted into worker container | Not mounted | `/var/run/docker.sock` in a container = root on the host |
| Sandbox: plain `docker run` | `--network none`, memory/CPU caps, read-only rootfs, non-root user | Generated code can't exfiltrate or touch RPCs |
| No dedupe, no rate limiting | DB dedupe + local budget (6 submissions/hr, platform allows 60) | One submission per listing is a platform rule |
| Plaintext DB password in compose | `.env` file, SQLite by default | No secrets in version control |

## Platform reality you must design around

1. **A human is mandatory for payouts.** Agents can't KYC. You register the agent,
   it earns a `claimCode`, and you claim winnings at `superteam.fun/earn/claim/<code>`
   with a completed talent profile + Solana wallet. This system treats HITL as the
   payout path, not a checkbox.
2. **Only `AGENT_ALLOWED` / `AGENT_ONLY` listings accept agents.** The scanner
   filters everything else. `AGENT_ONLY` listings are hidden from human feeds —
   smaller competition pool.
3. **Plagiarism = disqualification.** The worker prompt forbids reading other
   submissions, and no such API call exists in this codebase.
4. **These are competitions, not guaranteed wages.** The triage EV score uses a
   crude win-probability *prior*. Replace `_p_win_proxy` with your observed win
   rate once you have ~20 settled outcomes. Do not treat the score as a promise.

## Pipeline

```
scan (every 15 min)
  └─ GET /api/agents/listings/live
       └─ dedupe (SQLite) ─ triage EV filter
            └─ LangGraph: init → work (Goose/Claude Code) → validate (docker sandbox)
                 ├─ fail → rework (max 3) → give up
                 └─ pass → [INTERRUPT: Slack/Telegram ping] … you review …
                      └─ `approve <id> <url>` → POST /api/agents/submissions/create
```

You review the deliverable in `workspaces/<id>/`, host it (repo/gist), and pass
the URL at approval time. Nothing is ever submitted without your eyes on it —
which is also what keeps submission quality above the spam-flag threshold.

## Deploy

```bash
# 1. Host setup (Ubuntu)
sudo apt update && sudo apt install -y docker.io python3-pip
pip install -r requirements.txt
curl -fsSL https://github.com/block/goose/releases/latest/download/download_cli.sh | bash
docker pull python:3.11-slim

# 2. Register the agent (ONE TIME — save the claimCode offline, it's your payout key)
python main.py register my-agent-name

# 3. Configure
cp .env.example .env   # paste SUPERTEAM_API_KEY, set HUMAN_TELEGRAM_URL, webhooks

# 4. Dry run one cycle, inspect what it triages
python main.py scan
python main.py status

# 5. Run the daemon (or `docker compose up -d --build` for supervision)
python main.py daemon

# 6. When pinged on Slack/Telegram: review workspaces/<id>/, host the deliverable,
python main.py approve <opp-id> https://github.com/you/deliverable
```

## Tuning knobs (`.env`)

- `MIN_REWARD_USD` / `MIN_EV_SCORE` — raise these until the daemon only wakes
  you for work worth reviewing.
- `EST_COST_PER_ATTEMPT_USD` — set to your measured Goose/Claude token cost.
- `SKILL_TAGS` — match to what your worker actually produces well; skill match
  boosts triage priority.

---

# CEO Brain + x402 Storefront (v2 addition)

A second revenue loop: instead of only *earning* bounties, the system now also
*sells* to other AI agents — through real, verified infrastructure:

- **x402** (Coinbase's HTTP-402 payment standard) — production, millions of txs
  processed. Official Python SDK pinned at `x402==2.15.0`.
- **Bazaar** (Coinbase CDP's discovery index) — the "search engine for agents";
  buyer agents find your SKUs and pay in Base USDC autonomously. Each product
  route carries a schema-valid Bazaar discovery extension.
- **License NFT (optional)** — an ERC-721 on Base minted to the buyer as an
  on-chain license receipt for the SKU they purchased. This is the honest form
  of "selling NFTs to agents": agents buy *utility* (data, tools, reports);
  the NFT certifies the license. Nobody's agent buys hype jpegs.

## The CEO loop

```
python main.py ceo
```

1. Feeds REAL pipeline data (wins/losses/EV outcomes/sales) to Claude
   (claude-sonnet-4-6) — never fabricated metrics; "nothing worth selling"
   is an accepted answer.
2. Recommends triage tuning (you apply it to .env — the CEO can't rewrite config).
3. Proposes products from completed workspaces: bundles files into
   products/<sku>.zip, micro-priced $0.05–$25 for machine buyers.
4. **Ownership gate**: proposals are discarded unless the CEO affirms the work's
   rights did NOT transfer to a bounty sponsor. When unsure → not sold.
5. Everything lands as PROPOSED. Nothing is listed until YOU run:

```
python main.py products                 # review proposals + rationale
python main.py approve-product <sku>   # -> LISTED
python main.py storefront              # serve on :8402
```

## Storefront endpoints (standard x402 — any x402-capable agent can buy)

| Endpoint | Access | Purpose |
|---|---|---|
| `GET /catalog` | free | machine-readable SKU index |
| `GET /product/{sku}/meta` | free | what the buyer gets, pre-payment |
| `GET /product/{sku}` | **402 → USDC** | asset zip after settlement |
| `GET /health` | free | liveness |

Setup: set `STOREFRONT_PAYTO_ADDRESS` (receiving wallet on Base), start on
`base-sepolia` to test end-to-end with a testnet buyer before flipping
`STOREFRONT_NETWORK=base`. To mint license NFTs, deploy
`contracts/LicenseNFT.sol` (Remix/foundry), fund a **burner** key with ~$2 of
Base ETH, set `LICENSE_NFT_CONTRACT` + `MINT_BURNER_PRIVATE_KEY`
(gas-capped at `MINT_MAX_GAS_USD`, default $0.50/tx).

## Honest expectations

- Agent-to-agent commerce is real but early. Marketplace operators report
  buyer/seller imbalance favoring sellers (~5:1), which is why the storefront
  exists — but treat sales as a long-tail experiment, not projected revenue.
- What sells to agents: data feeds, scraped/cleaned datasets, reports, tools,
  and skill files with clear machine-readable descriptions. Price in cents.
- The CEO brain's product picks are proposals from an LLM. The approval gate
  exists because you know what's actually yours to sell and what's good enough
  to put your name on.
