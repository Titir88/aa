-- Superteam Earn agent orchestrator schema (PostgreSQL / SQLite compatible)

CREATE TABLE IF NOT EXISTS opportunities (
    id              VARCHAR(255) PRIMARY KEY,        -- superteam listing id
    slug            VARCHAR(255) UNIQUE,             -- listing slug for details endpoint
    listing_type    VARCHAR(20)  NOT NULL,           -- 'bounty' | 'project' | 'hackathon'
    agent_access    VARCHAR(20)  NOT NULL,           -- 'AGENT_ALLOWED' | 'AGENT_ONLY'
    title           VARCHAR(512) NOT NULL,
    description     TEXT,
    skills          TEXT,                            -- JSON array of skill tags
    reward_token    VARCHAR(16),
    reward_usd      DECIMAL(12,2) DEFAULT 0,
    compensation_type VARCHAR(20),                   -- 'fixed' | 'range' | 'variable'
    deadline        TIMESTAMP,
    platform_url    TEXT NOT NULL,
    ev_score        DECIMAL(8,4) DEFAULT 0,          -- triage expected-value score
    status          VARCHAR(30) DEFAULT 'DISCOVERED',
    -- DISCOVERED -> TRIAGED -> IN_PROGRESS -> WAITING_HITL -> SUBMITTED
    --            -> WON -> CLAIMED | REJECTED | SKIPPED | FAILED
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS executions (
    id              INTEGER PRIMARY KEY,
    opportunity_id  VARCHAR(255) REFERENCES opportunities(id),
    thread_id       VARCHAR(64) UNIQUE,              -- LangGraph checkpoint thread
    workspace_path  VARCHAR(512) NOT NULL,
    attempts        INTEGER DEFAULT 0,
    worker_logs     TEXT,
    test_results    TEXT,
    submission_link TEXT,                            -- deliverable URL (repo/gist/doc)
    submission_id   VARCHAR(255),                    -- returned by superteam on create
    completed_at    TIMESTAMP
);

CREATE TABLE IF NOT EXISTS safety_logs (
    id          INTEGER PRIMARY KEY,
    ts          TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    action_type VARCHAR(100) NOT NULL,   -- 'RATE_LIMIT', 'RETRY_CAP', 'EV_REJECT', 'DEDUPE_SKIP'
    details     TEXT NOT NULL
);

-- one submission per listing per agent (platform rule) — enforce locally too
CREATE UNIQUE INDEX IF NOT EXISTS uq_exec_opp ON executions(opportunity_id);

-- ===== CEO brain: productization & agent-to-agent sales =====

CREATE TABLE IF NOT EXISTS products (
    sku             VARCHAR(64) PRIMARY KEY,
    source_opp_id   VARCHAR(255) REFERENCES opportunities(id),  -- NULL if original product
    title           VARCHAR(255) NOT NULL,
    description     TEXT NOT NULL,               -- honest, machine-readable; no hype
    asset_path      VARCHAR(512) NOT NULL,       -- file served after payment
    price_usdc      DECIMAL(12,6) NOT NULL,      -- x402 micro-pricing, e.g. 0.25
    license_nft     INTEGER DEFAULT 0,           -- 1 = mint ERC-721 license to buyer
    status          VARCHAR(20) DEFAULT 'PROPOSED',
    -- PROPOSED (CEO suggested) -> APPROVED (human) -> LISTED -> RETIRED | REJECTED
    ceo_rationale   TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sales (
    id           INTEGER PRIMARY KEY,
    sku          VARCHAR(64) REFERENCES products(sku),
    payer        VARCHAR(64),                    -- buyer wallet from settlement
    amount_usdc  DECIMAL(12,6),
    tx_hash      VARCHAR(80),
    nft_token_id INTEGER,
    ts           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS ceo_reports (
    id        INTEGER PRIMARY KEY,
    ts        TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    report    TEXT NOT NULL                      -- JSON: analysis + proposals + tuning
);
