"""License NFT minter (Base). Optional — the storefront works without it.

Design decisions (honest version of "sell NFTs to agents"):
  - The NFT is a LICENSE RECEIPT for a product an agent already paid for via
    x402, not a speculative collectible. Agents buy utility; the token proves
    on-chain that wallet X holds a license to SKU Y.
  - Mints use a dedicated burner key with a hard per-tx gas cap. Never your
    main wallet. Same isolation rule as the rest of this repo.
  - Deploy contracts/LicenseNFT.sol yourself (Remix/foundry) and set
    LICENSE_NFT_CONTRACT. This module only calls mintTo(address,string).
"""
from __future__ import annotations

import os

from web3 import Web3

MINT_ABI = [{
    "name": "mintTo", "type": "function", "stateMutability": "nonpayable",
    "inputs": [{"name": "to", "type": "address"}, {"name": "uri", "type": "string"}],
    "outputs": [{"name": "tokenId", "type": "uint256"}],
}]

MAX_GAS_USD = float(os.getenv("MINT_MAX_GAS_USD", "0.50"))
ETH_USD_FALLBACK = float(os.getenv("ETH_USD_PRICE", "3000"))


class LicenseMinter:
    def __init__(self):
        rpc = os.getenv("BASE_RPC_URL", "https://mainnet.base.org")
        self.w3 = Web3(Web3.HTTPProvider(rpc))
        key = os.getenv("MINT_BURNER_PRIVATE_KEY")
        contract_addr = os.getenv("LICENSE_NFT_CONTRACT")
        if not key or not contract_addr:
            raise RuntimeError("Set MINT_BURNER_PRIVATE_KEY and LICENSE_NFT_CONTRACT to mint")
        self.acct = self.w3.eth.account.from_key(key)
        self.contract = self.w3.eth.contract(
            address=Web3.to_checksum_address(contract_addr), abi=MINT_ABI
        )

    def mint_license(self, buyer: str, sku: str, title: str) -> str:
        """Mint a license token to the buyer. Returns tx hash. Raises on gas breach."""
        buyer = Web3.to_checksum_address(buyer)
        uri = f"data:application/json,{{\"sku\":\"{sku}\",\"title\":\"{title}\",\"type\":\"x402-license\"}}"
        tx = self.contract.functions.mintTo(buyer, uri).build_transaction({
            "from": self.acct.address,
            "nonce": self.w3.eth.get_transaction_count(self.acct.address),
            "chainId": self.w3.eth.chain_id,
        })
        gas = self.w3.eth.estimate_gas(tx)
        gas_price = self.w3.eth.gas_price
        cost_eth = float(self.w3.from_wei(gas * gas_price, "ether"))
        cost_usd = cost_eth * ETH_USD_FALLBACK  # Base gas is cents; cap is a tripwire
        if cost_usd > MAX_GAS_USD:
            raise ValueError(f"mint gas ${cost_usd:.2f} exceeds cap ${MAX_GAS_USD:.2f}")
        tx["gas"] = int(gas * 1.2)
        signed = self.acct.sign_transaction(tx)
        tx_hash = self.w3.eth.send_raw_transaction(signed.raw_transaction)
        return self.w3.to_hex(tx_hash)
