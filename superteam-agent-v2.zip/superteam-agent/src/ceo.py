"""CEO brain: a strategy layer that runs on a slower loop than the bounty pipeline.

Two jobs, both grounded in real data from the local DB — never fabricated metrics:

1. PORTFOLIO REVIEW — reads settled outcomes (won/rejected/failed) and recommends
   triage tuning (min EV, skill focus). Output is a recommendation the human applies
   to .env; the CEO does not silently rewrite config.

2. PRODUCTIZATION — inspects completed workspaces and proposes which deliverables
   can be resold as agent-usable digital products (datasets, reports, skill files,
   tools) on the x402 storefront, with micro-pricing in USDC. Proposals land in the
   `products` table as PROPOSED. Nothing is listed or minted until a human runs
   `python main.py approve-product <sku>`.

Honesty rules baked into the prompt:
  - Only propose products with standalone utility to a machine buyer.
  - Descriptions must be factual and machine-readable. No scarcity theater,
    no invented performance claims, no reselling client-owned bounty work
    (work submitted to a sponsor may be theirs — the CEO must check the
    listing terms note in specifications.txt and default to NOT reselling
    if ownership transferred).
"""
from __future__ import annotations

import json
import re
import uuid
from pathlib import Path

import anthropic

from .config import Settings
from .db import Store

MODEL = "claude-sonnet-4-6"

SYSTEM = """You are the strategy officer for a small autonomous-agent business.
You receive real pipeline data. You must be brutally honest: if the data shows
losses or nothing worth productizing, say so plainly. Never invent metrics.

Respond with ONLY a JSON object, no markdown fences, with this shape:
{
  "analysis": "<3-6 sentence honest read of pipeline performance>",
  "triage_recommendations": {"min_ev_score": <float>, "skill_focus": ["..."], "reason": "..."},
  "product_proposals": [
    {
      "title": "...",
      "description": "<factual, machine-readable; what an AI agent buyer gets and why it is useful>",
      "source_opp_id": "<opportunity id or null>",
      "asset_files": ["relative/path/in/workspace"],
      "price_usdc": <float between 0.05 and 25.0>,
      "license_nft": <true|false>,
      "rationale": "<why an agent would pay for this; who the buyer is>",
      "ownership_ok": <true|false>,
      "ownership_note": "<does submitting this to the bounty sponsor transfer rights? if unsure, false>"
    }
  ],
  "skip_reason": "<if no proposals, why — this is a valid and often correct answer>"
}
Rules: propose at most 3 products. ownership_ok=false proposals will be discarded.
Price for machine buyers: micro-prices ($0.05-$5) for data/reports, up to $25 for tools.
"""


def _pipeline_snapshot(store: Store) -> dict:
    snap = {}
    for s in ("SUBMITTED", "WON", "REJECTED", "FAILED", "SKIPPED", "WAITING_HITL"):
        rows = store.get_by_status(s)
        snap[s] = [
            {"id": r["id"], "title": r["title"], "reward_usd": r["reward_usd"],
             "ev_score": r["ev_score"], "skills": r["skills"]}
            for r in rows[:15]
        ]
    return snap


def _completed_workspaces(store: Store, root: str) -> list[dict]:
    out = []
    for status in ("SUBMITTED", "WON", "FAILED"):
        for r in store.get_by_status(status):
            ws = Path(root) / str(r["id"])
            if not ws.exists():
                continue
            files = [str(p.relative_to(ws)) for p in ws.rglob("*")
                     if p.is_file() and p.suffix in
                     (".py", ".md", ".json", ".csv", ".js", ".ts", ".txt") and
                     p.name not in ("specifications.txt", ".goosehints", "error_log.txt")]
            spec = (ws / "specifications.txt")
            out.append({
                "opp_id": r["id"], "title": r["title"], "status": status,
                "files": files[:40],
                "spec_excerpt": spec.read_text(errors="ignore")[:800] if spec.exists() else "",
            })
    return out[:10]


def run_ceo_cycle(cfg: Settings, store: Store) -> dict:
    client = anthropic.Anthropic()  # ANTHROPIC_API_KEY from env
    payload = {
        "pipeline": _pipeline_snapshot(store),
        "completed_workspaces": _completed_workspaces(store, cfg.workspace_root),
        "current_triage": {"min_ev_score": cfg.min_ev_score,
                           "min_reward_usd": cfg.min_reward_usd,
                           "skill_tags": cfg.skill_tags},
        "recent_sales": _recent_sales(store),
    }
    msg = client.messages.create(
        model=MODEL, max_tokens=2000, system=SYSTEM,
        messages=[{"role": "user", "content": json.dumps(payload, default=str)}],
    )
    raw = "".join(b.text for b in msg.content if b.type == "text")
    raw = re.sub(r"^```(json)?|```$", "", raw.strip(), flags=re.M).strip()
    report = json.loads(raw)

    accepted = []
    for p in report.get("product_proposals", []):
        if not p.get("ownership_ok"):
            continue  # never resell work whose rights transferred to a sponsor
        price = float(p.get("price_usdc", 0))
        if not (0.05 <= price <= 25.0):
            continue
        sku = f"sku_{uuid.uuid4().hex[:10]}"
        asset = _bundle_asset(cfg, p, sku)
        if not asset:
            continue
        store.add_product(
            sku=sku, source_opp_id=p.get("source_opp_id"),
            title=p["title"][:255], description=p["description"],
            asset_path=asset, price_usdc=price,
            license_nft=1 if p.get("license_nft") else 0,
            ceo_rationale=p.get("rationale", ""),
        )
        accepted.append(sku)

    store.save_ceo_report(json.dumps({**report, "accepted_skus": accepted}, default=str))
    return {**report, "accepted_skus": accepted}


def _bundle_asset(cfg: Settings, proposal: dict, sku: str) -> str | None:
    """Zip the proposed files from the source workspace into products/<sku>.zip."""
    import zipfile
    opp_id = proposal.get("source_opp_id")
    if not opp_id:
        return None
    ws = Path(cfg.workspace_root) / str(opp_id)
    files = [ws / f for f in proposal.get("asset_files", []) if (ws / f).is_file()]
    if not files:
        return None
    out_dir = Path("products")
    out_dir.mkdir(exist_ok=True)
    out = out_dir / f"{sku}.zip"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            z.write(f, arcname=f.name)
    return str(out)


def _recent_sales(store: Store) -> list[dict]:
    try:
        return store.recent_sales(20)
    except Exception:
        return []
