"""Superteam Earn Agent API client.

Endpoints verified against the official spec (https://superteam.fun/skill.md):
  POST /api/agents                        -> register (returns apiKey, claimCode, agentId)
  GET  /api/agents/listings/live          -> agent-eligible listings (bounty|project|hackathon)
  GET  /api/agents/listings/details/<slug>
  POST /api/agents/submissions/create
  POST /api/agents/submissions/update
  GET  /api/agents/comments/<listing-id>
  POST /api/agents/comments/create

Platform rules encoded here:
  - Only AGENT_ALLOWED / AGENT_ONLY listings accept agent submissions.
  - Rate limits: 60 submissions/hr/agent (we self-throttle far below).
  - `telegram` (t.me URL of the human operator) required for project listings.
  - `ask` required when compensationType is range|variable.
  - Never fetch other submissions on a listing (plagiarism rule) — no such call exists here.
"""
from __future__ import annotations

import time
import httpx


class SuperteamClient:
    def __init__(self, base_url: str, api_key: str):
        self.base = base_url.rstrip("/")
        self._client = httpx.Client(
            timeout=30,
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        )
        self._last_call = 0.0

    def _throttle(self, min_gap: float = 1.5):
        gap = time.monotonic() - self._last_call
        if gap < min_gap:
            time.sleep(min_gap - gap)
        self._last_call = time.monotonic()

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        self._throttle()
        r = self._client.get(f"{self.base}{path}", params=params)
        if r.status_code == 429:
            time.sleep(60)
            r = self._client.get(f"{self.base}{path}", params=params)
        r.raise_for_status()
        return r.json()

    def _post(self, path: str, payload: dict) -> dict:
        self._throttle()
        r = self._client.post(f"{self.base}{path}", json=payload)
        if r.status_code == 429:
            raise RateLimited(r.text)
        r.raise_for_status()
        return r.json()

    # ---------- registration (one-time; run scripts/register.py) ----------
    @staticmethod
    def register(base_url: str, name: str) -> dict:
        r = httpx.post(f"{base_url.rstrip('/')}/api/agents", json={"name": name}, timeout=30)
        r.raise_for_status()
        return r.json()  # {apiKey, claimCode, agentId, username}

    # ---------- discovery ----------
    def live_listings(self, take: int = 50, listing_type: str | None = None) -> list[dict]:
        params: dict = {"take": take}
        if listing_type:
            params["type"] = listing_type  # bounty | project | hackathon
        data = self._get("/api/agents/listings/live", params)
        listings = data.get("listings", data) if isinstance(data, dict) else data
        return [self._normalize(item) for item in listings]

    def listing_details(self, slug: str) -> dict:
        return self._get(f"/api/agents/listings/details/{slug}")  # type: ignore[return-value]

    # ---------- submission ----------
    def submit(
        self,
        listing_id: str,
        link: str,
        other_info: str,
        telegram: str,
        eligibility_answers: list[dict] | None = None,
        ask: float | None = None,
        is_project: bool = False,
    ) -> dict:
        payload = {
            "listingId": listing_id,
            "link": link,
            "tweet": "",
            "otherInfo": other_info,
            "eligibilityAnswers": eligibility_answers or [],
            "ask": ask,
        }
        # telegram is REQUIRED for project listings, optional otherwise
        if is_project or telegram:
            payload["telegram"] = telegram
        return self._post("/api/agents/submissions/create", payload)

    # ---------- clarification comments ----------
    def ask_question(self, listing_id: str, message: str, poc_id: str) -> dict:
        return self._post(
            "/api/agents/comments/create",
            {"refType": "BOUNTY", "refId": listing_id, "message": message, "pocId": poc_id},
        )

    # ---------- normalization ----------
    @staticmethod
    def _normalize(item: dict) -> dict:
        """Map API payload to internal opportunity dict. Defensive on field names."""
        reward_usd = item.get("usdValue") or item.get("rewardUsd") or item.get("rewardAmount") or 0
        return {
            "id": str(item.get("id")),
            "slug": item.get("slug"),
            "listing_type": (item.get("type") or "bounty").lower(),
            "agent_access": item.get("agentAccess", "AGENT_ALLOWED"),
            "title": item.get("title", ""),
            "description": item.get("description", ""),
            "skills": item.get("skills", []),
            "reward_token": item.get("token"),
            "reward_usd": float(reward_usd or 0),
            "compensation_type": (item.get("compensationType") or "fixed").lower(),
            "deadline": item.get("deadline"),
            "platform_url": f"https://superteam.fun/earn/listing/{item.get('slug', '')}",
        }


class RateLimited(Exception):
    pass
