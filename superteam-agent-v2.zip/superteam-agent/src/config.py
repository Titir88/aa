"""Central config. Fails fast on missing required env vars."""
import os
from dataclasses import dataclass, field


def _req(name: str) -> str:
    v = os.getenv(name)
    if not v:
        raise RuntimeError(f"Missing required env var: {name}")
    return v


@dataclass(frozen=True)
class Settings:
    # Superteam Earn agent API (real, documented at https://superteam.fun/skill.md)
    superteam_base_url: str = os.getenv("SUPERTEAM_BASE_URL", "https://superteam.fun")
    superteam_api_key: str = field(default_factory=lambda: _req("SUPERTEAM_API_KEY"))
    agent_name: str = os.getenv("AGENT_NAME", "my-agent")
    human_telegram: str = field(default_factory=lambda: _req("HUMAN_TELEGRAM_URL"))  # t.me/<user>

    # Storage
    database_path: str = os.getenv("DATABASE_PATH", "./data/orchestrator.db")
    checkpoint_path: str = os.getenv("CHECKPOINT_PATH", "./data/checkpoints.db")
    workspace_root: str = os.getenv("WORKSPACE_ROOT", "./workspaces")

    # Worker (Goose or Claude Code CLI)
    worker_cmd: str = os.getenv("WORKER_CMD", "goose")           # or "claude"
    worker_timeout_s: int = int(os.getenv("WORKER_TIMEOUT_S", "600"))
    max_rework_attempts: int = int(os.getenv("MAX_REWORK_ATTEMPTS", "3"))

    # Triage
    min_reward_usd: float = float(os.getenv("MIN_REWARD_USD", "50"))
    min_ev_score: float = float(os.getenv("MIN_EV_SCORE", "0.5"))
    skill_tags: str = os.getenv("SKILL_TAGS", "Backend,Blockchain,Content,Other")
    est_cost_per_attempt_usd: float = float(os.getenv("EST_COST_PER_ATTEMPT_USD", "3"))

    # Notifications (HITL)
    slack_webhook_url: str = os.getenv("SLACK_WEBHOOK_URL", "")
    telegram_bot_token: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    telegram_chat_id: str = os.getenv("TELEGRAM_CHAT_ID", "")

    # Sandbox
    sandbox_image: str = os.getenv("SANDBOX_IMAGE", "python:3.11-slim")
    sandbox_enabled: bool = os.getenv("SANDBOX_ENABLED", "1") == "1"

    # Scan cadence — stay far under platform rate limits (60 submissions/hr/agent)
    scan_interval_s: int = int(os.getenv("SCAN_INTERVAL_S", "900"))
    max_submissions_per_hour: int = int(os.getenv("MAX_SUBMISSIONS_PER_HOUR", "6"))


def load_settings() -> Settings:
    return Settings()
