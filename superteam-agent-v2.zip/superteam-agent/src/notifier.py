"""Notifier: pushes HITL approval requests to Slack and/or Telegram."""
from __future__ import annotations

import httpx

from .config import Settings


def notify(cfg: Settings, title: str, body: str) -> None:
    text = f"*{title}*\n{body}"
    if cfg.slack_webhook_url:
        try:
            httpx.post(cfg.slack_webhook_url, json={"text": text}, timeout=15)
        except Exception as e:
            print(f"[notifier] slack failed: {e}")
    if cfg.telegram_bot_token and cfg.telegram_chat_id:
        try:
            httpx.post(
                f"https://api.telegram.org/bot{cfg.telegram_bot_token}/sendMessage",
                json={"chat_id": cfg.telegram_chat_id, "text": f"{title}\n{body}"},
                timeout=15,
            )
        except Exception as e:
            print(f"[notifier] telegram failed: {e}")


def notify_hitl(cfg: Settings, opp: dict, workspace: str, test_summary: str) -> None:
    notify(
        cfg,
        f"✅ Ready for review: {opp['title']}",
        f"Reward: ${opp.get('reward_usd', 0):.0f} {opp.get('reward_token') or ''}\n"
        f"Listing: {opp.get('platform_url')}\n"
        f"Workspace: {workspace}\n"
        f"Tests: {test_summary[:300]}\n\n"
        f"Review the deliverable, upload it somewhere public (repo/gist), then run:\n"
        f"  python main.py approve {opp['id']} <deliverable-url>\n"
        f"or reject with:\n"
        f"  python main.py reject {opp['id']}",
    )
