"""Validator: runs agent-generated tests inside a locked-down Docker container.

Hardening vs. the original blueprint:
  --network none      no exfiltration / no mainnet calls from generated code
  --memory / --cpus   resource caps
  --read-only rootfs with a writable /tmp only
  runs as non-root (uid 1000)
"""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from .config import Settings


def validate(workspace: str, cfg: Settings) -> tuple[bool, str]:
    ws = Path(workspace)
    has_tests = (ws / "test_solution.py").exists()
    has_doc = (ws / "DELIVERABLE.md").exists()

    if not has_tests and has_doc:
        # documentation/content deliverable: basic sanity check instead of pytest
        text = (ws / "DELIVERABLE.md").read_text(errors="ignore")
        ok = len(text.strip()) > 400
        return ok, "doc deliverable length check " + ("passed" if ok else "failed (<400 chars)")

    if not has_tests:
        return False, "missing test_solution.py and no DELIVERABLE.md"

    if not cfg.sandbox_enabled:
        cmd = ["python", "-m", "pytest", "test_solution.py", "-q", "--timeout=120"]
        result = subprocess.run(cmd, cwd=workspace, capture_output=True, text=True, timeout=300)
    else:
        cmd = [
            "docker", "run", "--rm",
            "--network", "none",
            "--memory", "512m", "--cpus", "1",
            "--read-only", "--tmpfs", "/tmp:rw,size=128m",
            "--user", "1000:1000",
            "-v", f"{os.path.abspath(workspace)}:/app:ro",
            "-w", "/app",
            cfg.sandbox_image,
            "python", "-m", "pytest", "test_solution.py", "-q",
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
        except subprocess.TimeoutExpired:
            return False, "sandbox validation timed out"

    output = (result.stdout or "") + (result.stderr or "")
    if result.returncode == 0:
        return True, output[-2000:]
    (ws / "error_log.txt").write_text(output[-8000:])
    return False, output[-2000:]
