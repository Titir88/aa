"""Thin SQLite persistence layer (swap for Postgres via DATABASE_URL later if needed)."""
import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

_LOCK = threading.Lock()


class Store:
    def __init__(self, db_path: str, schema_path: str = "database/schema.sql"):
        Path(os.path.dirname(db_path) or ".").mkdir(parents=True, exist_ok=True)
        self.db_path = db_path
        with self._conn() as c:
            c.executescript(Path(schema_path).read_text())

    @contextmanager
    def _conn(self):
        conn = sqlite3.connect(self.db_path, timeout=30)
        conn.row_factory = sqlite3.Row
        try:
            with _LOCK:
                yield conn
                conn.commit()
        finally:
            conn.close()

    # ---------- opportunities ----------
    def upsert_opportunity(self, opp: dict) -> bool:
        """Insert if new. Returns True if newly inserted (i.e., not a duplicate)."""
        with self._conn() as c:
            cur = c.execute("SELECT status FROM opportunities WHERE id = ?", (opp["id"],))
            if cur.fetchone():
                return False
            c.execute(
                """INSERT INTO opportunities
                   (id, slug, listing_type, agent_access, title, description, skills,
                    reward_token, reward_usd, compensation_type, deadline, platform_url,
                    ev_score, status)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    opp["id"], opp.get("slug"), opp.get("listing_type", "bounty"),
                    opp.get("agent_access", "AGENT_ALLOWED"), opp["title"],
                    opp.get("description", ""), json.dumps(opp.get("skills", [])),
                    opp.get("reward_token"), opp.get("reward_usd", 0),
                    opp.get("compensation_type", "fixed"), opp.get("deadline"),
                    opp["platform_url"], opp.get("ev_score", 0), "DISCOVERED",
                ),
            )
            return True

    def set_status(self, opp_id: str, status: str):
        with self._conn() as c:
            c.execute(
                "UPDATE opportunities SET status = ?, updated_at = ? WHERE id = ?",
                (status, datetime.now(timezone.utc).isoformat(), opp_id),
            )

    def get_by_status(self, status: str) -> list[dict]:
        with self._conn() as c:
            rows = c.execute(
                "SELECT * FROM opportunities WHERE status = ? ORDER BY ev_score DESC", (status,)
            ).fetchall()
            return [dict(r) for r in rows]

    def already_worked(self, opp_id: str) -> bool:
        with self._conn() as c:
            r = c.execute("SELECT 1 FROM executions WHERE opportunity_id = ?", (opp_id,)).fetchone()
            return r is not None

    # ---------- executions ----------
    def start_execution(self, opp_id: str, thread_id: str, workspace: str):
        with self._conn() as c:
            c.execute(
                """INSERT OR IGNORE INTO executions (opportunity_id, thread_id, workspace_path)
                   VALUES (?,?,?)""",
                (opp_id, thread_id, workspace),
            )

    def update_execution(self, opp_id: str, **fields):
        allowed = {"attempts", "worker_logs", "test_results", "submission_link",
                   "submission_id", "completed_at"}
        sets, vals = [], []
        for k, v in fields.items():
            if k in allowed:
                sets.append(f"{k} = ?")
                vals.append(v)
        if not sets:
            return
        vals.append(opp_id)
        with self._conn() as c:
            c.execute(f"UPDATE executions SET {', '.join(sets)} WHERE opportunity_id = ?", vals)

    def submissions_in_last_hour(self) -> int:
        with self._conn() as c:
            r = c.execute(
                """SELECT COUNT(*) AS n FROM executions
                   WHERE completed_at IS NOT NULL
                     AND completed_at >= datetime('now', '-1 hour')"""
            ).fetchone()
            return int(r["n"])

    # ---------- safety ----------
    def log_safety(self, action_type: str, details: str):
        with self._conn() as c:
            c.execute(
                "INSERT INTO safety_logs (action_type, details) VALUES (?,?)",
                (action_type, details),
            )

    # ---------- products (CEO brain) ----------
    def add_product(self, sku, title, description, asset_path, price_usdc,
                    license_nft=0, source_opp_id=None, ceo_rationale=""):
        with self._conn() as c:
            c.execute(
                """INSERT INTO products
                   (sku, source_opp_id, title, description, asset_path, price_usdc,
                    license_nft, status, ceo_rationale)
                   VALUES (?,?,?,?,?,?,?,'PROPOSED',?)""",
                (sku, source_opp_id, title, description, asset_path,
                 price_usdc, license_nft, ceo_rationale),
            )

    def get_product(self, sku) -> dict | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM products WHERE sku = ?", (sku,)).fetchone()
            return dict(r) if r else None

    def products_by_status(self, status) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM products WHERE status = ?", (status,)).fetchall()
            return [dict(r) for r in rows]

    def listed_products(self) -> list[dict]:
        return self.products_by_status("LISTED")

    def set_product_status(self, sku, status):
        with self._conn() as c:
            c.execute("UPDATE products SET status = ? WHERE sku = ?", (status, sku))

    def record_sale(self, sku, payer, amount_usdc, tx_hash="", nft_token_id=None):
        with self._conn() as c:
            c.execute(
                "INSERT INTO sales (sku, payer, amount_usdc, tx_hash, nft_token_id) VALUES (?,?,?,?,?)",
                (sku, payer, amount_usdc, tx_hash, nft_token_id),
            )

    def recent_sales(self, n=20) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT * FROM sales ORDER BY ts DESC LIMIT ?", (n,)).fetchall()
            return [dict(r) for r in rows]

    def save_ceo_report(self, report_json: str):
        with self._conn() as c:
            c.execute("INSERT INTO ceo_reports (report) VALUES (?)", (report_json,))
