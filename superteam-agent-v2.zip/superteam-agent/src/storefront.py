"""x402 storefront: sells APPROVED/LISTED products to other AI agents.

Built on the official x402 Python SDK (pin x402==2.15.0) with FastAPI middleware.
Payment rail: Base USDC via the x402 facilitator (default https://x402.org/facilitator,
or Coinbase CDP facilitator for Bazaar indexing).

Flow (fully standard x402, so any x402-capable buyer agent can purchase):
  GET /catalog                  free, machine-readable SKU index (Bazaar-compatible)
  GET /product/{sku}            402 Payment Required -> buyer pays USDC -> asset zip
  GET /product/{sku}/meta       free metadata (what the buyer gets, before paying)

On settlement, the sale is recorded; if the product has license_nft=1 and
LICENSE_NFT_CONTRACT is configured, an ERC-721 license is minted to the payer
address on Base (see src/mint.py + contracts/LicenseNFT.sol).

Run: python main.py storefront   (serves on STOREFRONT_PORT, default 8402)
"""
from __future__ import annotations

import os
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from .db import Store


def build_app(store: Store) -> FastAPI:
    pay_to = os.getenv("STOREFRONT_PAYTO_ADDRESS", "")
    network = os.getenv("STOREFRONT_NETWORK", "base")      # 'base' | 'base-sepolia'
    if not pay_to:
        raise RuntimeError("Set STOREFRONT_PAYTO_ADDRESS (your receiving wallet on Base)")

    app = FastAPI(title="agent-storefront", version="1.0")

    # ---- x402 payment middleware over listed products ----
    from x402.extensions.bazaar import OutputConfig, declare_discovery_extension

    listed = {p["sku"]: p for p in store.listed_products()}
    routes = {}
    for sku, p in listed.items():
        routes[f"GET /product/{sku}"] = {
            "price": f"${float(p['price_usdc']):.6f}",
            "network": network,
            "pay_to": pay_to,
            # Bazaar discovery extension (official SDK helper -> {"info","schema"} shape)
            "extensions": declare_discovery_extension(
                input={"method": "GET"},
                output=OutputConfig(schema={
                    "type": "string",
                    "contentMediaType": "application/zip",
                    "description": f"{p['title']}: {p['description'][:300]}",
                }),
            ),
        }

    from x402.http import FacilitatorConfig, HTTPFacilitatorClient
    from x402.http.middleware.fastapi import payment_middleware_from_config

    facilitator_url = os.getenv("X402_FACILITATOR_URL", "https://x402.org/facilitator")
    sync_on_start = os.getenv("X402_SYNC_FACILITATOR", "1") == "1"
    if routes:
        facilitator = HTTPFacilitatorClient(FacilitatorConfig(url=facilitator_url))
        mw = payment_middleware_from_config(
            routes=routes,
            facilitator_client=facilitator,  # verification/settlement via facilitator
            sync_facilitator_on_start=sync_on_start,
        )
        app.add_middleware(BaseHTTPMiddleware, dispatch=mw)

    # ---- free discovery endpoints ----
    @app.get("/catalog")
    def catalog():
        return {
            "seller": "superteam-agent-storefront",
            "payment": {"protocol": "x402", "network": network, "asset": "USDC"},
            "products": [
                {
                    "sku": p["sku"],
                    "title": p["title"],
                    "description": p["description"],
                    "price_usdc": float(p["price_usdc"]),
                    "license_nft": bool(p["license_nft"]),
                    "endpoint": f"/product/{p['sku']}",
                }
                for p in store.listed_products()
            ],
        }

    @app.get("/product/{sku}/meta")
    def meta(sku: str):
        p = store.get_product(sku)
        if not p or p["status"] != "LISTED":
            raise HTTPException(404)
        return {k: p[k] for k in ("sku", "title", "description", "price_usdc", "license_nft")}

    # ---- paid endpoint (middleware settles payment before this runs) ----
    @app.get("/product/{sku}")
    def product(sku: str):
        p = store.get_product(sku)
        if not p or p["status"] != "LISTED":
            raise HTTPException(404, "unknown or unlisted sku")
        asset = Path(p["asset_path"])
        if not asset.exists():
            raise HTTPException(500, "asset missing — contact seller")
        # Settlement details (payer, tx) are exposed by middleware response headers;
        # record the sale with what we have. NFT licensing runs out-of-band via
        # `python main.py mint-pending` so a chain hiccup never blocks delivery.
        store.record_sale(sku=sku, payer="", amount_usdc=float(p["price_usdc"]), tx_hash="")
        return FileResponse(asset, media_type="application/zip", filename=f"{sku}.zip")

    @app.get("/health")
    def health():
        return {"status": "ok", "listed": len(listed)}

    return app


def serve(store: Store):
    import uvicorn
    port = int(os.getenv("STOREFRONT_PORT", "8402"))
    uvicorn.run(build_app(store), host="0.0.0.0", port=port)
