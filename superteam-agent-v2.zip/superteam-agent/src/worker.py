"""Worker: spawns a local coding agent (Goose or Claude Code CLI) in the task workspace."""
from __future__ import annotations

import os
import subprocess
from pathlib import Path

from .config import Settings

GOOSEHINTS = """\
- You are a sub-agent completing ONE bounty deliverable in this directory only.
- Read specifications.txt first. Produce exactly what the listing asks for.
- All code must ship with tests in test_solution.py (pytest). Docs deliverables
  ship as DELIVERABLE.md with a SUMMARY.md.
- Original work only. Do not search for or copy other people's submissions
  to this listing (platform plagiarism rule -> disqualification).
- No network calls to mainnet RPCs. No private keys. No credentials.
- No infinite loops, no daemons, no writing outside this directory.
- If the spec is ambiguous, write your open questions to QUESTIONS.md and
  produce the best-effort deliverable anyway.
"""


def prepare_workspace(root: str, opp: dict) -> str:
    path = Path(root) / str(opp["id"])
    path.mkdir(parents=True, exist_ok=True)
    (path / "specifications.txt").write_text(
        f"TASK: {opp['title']}\n"
        f"TYPE: {opp.get('listing_type')}\n"
        f"REWARD: {opp.get('reward_usd')} USD ({opp.get('reward_token')})\n"
        f"URL: {opp.get('platform_url')}\n\n"
        f"{opp.get('description', '')}\n"
    )
    (path / ".goosehints").write_text(GOOSEHINTS)
    return str(path)


def run_worker(workspace: str, cfg: Settings, error_context: str = "") -> tuple[bool, str]:
    """Run one worker pass. Returns (spawned_ok, logs)."""
    instructions = (
        "Read specifications.txt and .goosehints. Build the deliverable in this "
        "directory, with tests in test_solution.py."
    )
    if error_context:
        instructions += (
            " A previous attempt failed validation. Read error_log.txt and fix "
            "the deliverable; do not start over unless necessary."
        )

    if cfg.worker_cmd == "claude":
        cmd = ["claude", "-p", instructions, "--dangerously-skip-permissions"]
    else:
        cmd = ["goose", "run", "--instructions", instructions]

    env = {k: v for k, v in os.environ.items()
           if not any(s in k for s in ("PRIVATE_KEY", "SEED", "MNEMONIC"))}
    try:
        result = subprocess.run(
            cmd, cwd=workspace, capture_output=True, text=True,
            timeout=cfg.worker_timeout_s, env=env,
        )
        return True, (result.stdout or "") + (result.stderr or "")
    except subprocess.TimeoutExpired:
        return False, f"worker timed out after {cfg.worker_timeout_s}s"
    except FileNotFoundError:
        return False, f"worker binary '{cfg.worker_cmd}' not found on PATH"
