"""Orchestrator: LangGraph state machine with durable checkpoints.

Fixes vs. the original blueprint:
  - SqliteSaver checkpointing: WAITING_HITL survives process restarts.
  - interrupt_before=["hitl"]: graph genuinely pauses for human approval and is
    resumed by `approve_and_submit()` with the same thread_id.
  - Retry cap (max_rework_attempts): the rework loop can no longer burn tokens forever.
  - Submission node calls the real Superteam endpoint and respects a local
    submissions/hour budget well under the platform's 60/hr limit.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from typing import TypedDict

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, StateGraph

from . import notifier, triage, validator, worker
from .config import Settings
from .db import Store
from .superteam import RateLimited, SuperteamClient


class AgentState(TypedDict, total=False):
    opportunity: dict
    workspace: str
    attempts: int
    worker_logs: str
    test_summary: str
    validation_passed: bool
    submission_link: str      # filled in by the human at approval time
    submitted: bool
    failure_reason: str


class Orchestrator:
    def __init__(self, cfg: Settings, store: Store, client: SuperteamClient):
        self.cfg = cfg
        self.store = store
        self.client = client
        conn = sqlite3.connect(cfg.checkpoint_path, check_same_thread=False)
        self.checkpointer = SqliteSaver(conn)
        self.graph = self._build()

    # ---------- nodes ----------
    def n_init(self, state: AgentState) -> dict:
        opp = state["opportunity"]
        ws = worker.prepare_workspace(self.cfg.workspace_root, opp)
        self.store.start_execution(opp["id"], thread_id=opp["id"], workspace=ws)
        self.store.set_status(opp["id"], "IN_PROGRESS")
        return {"workspace": ws, "attempts": 0}

    def n_work(self, state: AgentState) -> dict:
        attempts = state.get("attempts", 0) + 1
        err = ""
        if attempts > 1:
            err = "previous attempt failed"
        ok, logs = worker.run_worker(state["workspace"], self.cfg, error_context=err)
        self.store.update_execution(state["opportunity"]["id"], attempts=attempts,
                                    worker_logs=logs[-8000:])
        return {"attempts": attempts, "worker_logs": logs,
                "failure_reason": "" if ok else logs}

    def n_validate(self, state: AgentState) -> dict:
        passed, summary = validator.validate(state["workspace"], self.cfg)
        self.store.update_execution(state["opportunity"]["id"], test_results=summary[:4000])
        return {"validation_passed": passed, "test_summary": summary}

    def n_hitl(self, state: AgentState) -> dict:
        # Reached only after validation passes; graph interrupts BEFORE this node,
        # so by the time it runs, a human has resumed us with submission_link set.
        return {}

    def n_submit(self, state: AgentState) -> dict:
        opp = state["opportunity"]
        if self.store.submissions_in_last_hour() >= self.cfg.max_submissions_per_hour:
            self.store.log_safety("RATE_LIMIT", f"local submission budget hit; deferring {opp['id']}")
            return {"submitted": False, "failure_reason": "local rate budget exhausted"}
        link = state.get("submission_link", "")
        if not link:
            return {"submitted": False, "failure_reason": "no deliverable link provided at approval"}
        try:
            ask = None
            if opp.get("compensation_type") in ("range", "variable"):
                ask = float(opp.get("reward_usd") or self.cfg.min_reward_usd)
            resp = self.client.submit(
                listing_id=opp["id"],
                link=link,
                other_info=f"Automated build, human-reviewed. Tests: "
                           f"{state.get('test_summary', '')[:400]}",
                telegram=self.cfg.human_telegram,
                ask=ask,
                is_project=(opp.get("listing_type") == "project"),
            )
            self.store.update_execution(
                opp["id"],
                submission_link=link,
                submission_id=str(resp.get("id", "")),
                completed_at=datetime.now(timezone.utc).isoformat(),
            )
            self.store.set_status(opp["id"], "SUBMITTED")
            notifier.notify(self.cfg, f"📤 Submitted: {opp['title']}", link)
            return {"submitted": True}
        except RateLimited:
            self.store.log_safety("RATE_LIMIT", f"platform 429 on {opp['id']}")
            return {"submitted": False, "failure_reason": "platform rate limited"}
        except Exception as e:
            self.store.set_status(opp["id"], "FAILED")
            return {"submitted": False, "failure_reason": str(e)}

    # ---------- edges ----------
    def route_after_validate(self, state: AgentState) -> str:
        if state.get("validation_passed"):
            opp = state["opportunity"]
            self.store.set_status(opp["id"], "WAITING_HITL")
            notifier.notify_hitl(self.cfg, opp, state["workspace"],
                                 state.get("test_summary", ""))
            return "hitl"
        if state.get("attempts", 0) >= self.cfg.max_rework_attempts:
            opp_id = state["opportunity"]["id"]
            self.store.log_safety("RETRY_CAP", f"{opp_id} failed {state['attempts']} attempts")
            self.store.set_status(opp_id, "FAILED")
            return "give_up"
        return "rework"

    def _build(self):
        g = StateGraph(AgentState)
        g.add_node("init", self.n_init)
        g.add_node("work", self.n_work)
        g.add_node("validate", self.n_validate)
        g.add_node("hitl", self.n_hitl)
        g.add_node("submit", self.n_submit)

        g.set_entry_point("init")
        g.add_edge("init", "work")
        g.add_edge("work", "validate")
        g.add_conditional_edges("validate", self.route_after_validate,
                                {"hitl": "hitl", "rework": "work", "give_up": END})
        g.add_edge("hitl", "submit")
        g.add_edge("submit", END)
        return g.compile(checkpointer=self.checkpointer, interrupt_before=["hitl"])

    # ---------- public API ----------
    def run_opportunity(self, opp: dict) -> None:
        """Run until the graph pauses at HITL (or gives up)."""
        config = {"configurable": {"thread_id": opp["id"]}}
        self.graph.invoke({"opportunity": opp}, config)

    def approve_and_submit(self, opp_id: str, deliverable_link: str) -> None:
        """Human approval hook: injects the reviewed deliverable URL and resumes."""
        config = {"configurable": {"thread_id": opp_id}}
        self.graph.update_state(config, {"submission_link": deliverable_link})
        self.graph.invoke(None, config)  # resumes at 'hitl' -> 'submit'

    def reject(self, opp_id: str) -> None:
        self.store.set_status(opp_id, "SKIPPED")

    # ---------- discovery + triage ----------
    def scan_and_dispatch(self) -> int:
        """One scan cycle: fetch, dedupe, score, dispatch best candidates."""
        dispatched = 0
        listings = self.client.live_listings(take=50)
        for opp in listings:
            if opp.get("agent_access") not in ("AGENT_ALLOWED", "AGENT_ONLY"):
                continue  # never touch human-only listings
            is_new = self.store.upsert_opportunity(opp)
            if not is_new or self.store.already_worked(opp["id"]):
                if not is_new:
                    continue
            ev, reason = triage.score(opp, self.cfg)
            if ev < self.cfg.min_ev_score:
                self.store.log_safety("EV_REJECT", f"{opp['id']}: {reason} (ev={ev})")
                self.store.set_status(opp["id"], "SKIPPED")
                continue
            self.store.set_status(opp["id"], "TRIAGED")
            print(f"[scan] dispatching {opp['title']} (ev={ev}, {reason})")
            self.run_opportunity(opp)
            dispatched += 1
        return dispatched
