"""Triage: decide which discovered listings are worth spending tokens on.

EV heuristic (honest version — no fabricated 'proven edge'):
  EV = reward_usd * p_win_proxy - est_cost

p_win_proxy is a crude prior, NOT an empirical win rate. Replace it with your
actual observed win rate per (listing_type, skill) once you have >=20 settled
outcomes. Until then treat scores as a ranking device, not a probability.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone

from .config import Settings


def _p_win_proxy(opp: dict, my_skills: set[str]) -> float:
    p = 0.05  # base prior for open bounty competitions
    if opp.get("agent_access") == "AGENT_ONLY":
        p += 0.10  # smaller field: only agents compete
    skills = opp.get("skills") or []
    if isinstance(skills, str):
        try:
            skills = json.loads(skills)
        except Exception:
            skills = [skills]
    if my_skills & {str(s) for s in skills}:
        p += 0.05
    if (opp.get("listing_type") or "bounty") == "project":
        p *= 0.6  # projects are selective applications, lower hit rate
    return min(p, 0.5)


def _hours_left(deadline: str | None) -> float:
    if not deadline:
        return 999.0
    try:
        dt = datetime.fromisoformat(str(deadline).replace("Z", "+00:00"))
        return max((dt - datetime.now(timezone.utc)).total_seconds() / 3600, 0)
    except Exception:
        return 999.0


def score(opp: dict, cfg: Settings) -> tuple[float, str]:
    """Returns (ev_score, reason). ev_score <= 0 means skip."""
    reward = float(opp.get("reward_usd") or 0)
    comp = opp.get("compensation_type", "fixed")

    if comp == "fixed" and reward < cfg.min_reward_usd:
        return -1.0, f"reward ${reward:.0f} below floor ${cfg.min_reward_usd:.0f}"

    if _hours_left(opp.get("deadline")) < 6:
        return -1.0, "deadline under 6h — not enough runway for HITL review"

    my_skills = {s.strip() for s in cfg.skill_tags.split(",") if s.strip()}
    p = _p_win_proxy(opp, my_skills)
    # variable/range comp: assume we ask near the floor, value it conservatively
    effective_reward = reward if comp == "fixed" else max(reward, cfg.min_reward_usd)
    ev = effective_reward * p - cfg.est_cost_per_attempt_usd
    return round(ev, 4), f"p_win_proxy={p:.2f}, reward=${effective_reward:.0f}"
