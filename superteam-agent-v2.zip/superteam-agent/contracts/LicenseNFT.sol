// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/// @title LicenseNFT — on-chain license receipts for x402 storefront purchases.
/// @notice Each token certifies that its holder purchased a specific product SKU.
///         Minted only by the storefront's burner key (contract owner).
contract LicenseNFT is ERC721URIStorage, Ownable {
    uint256 private _nextId = 1;

    constructor() ERC721("AgentStorefrontLicense", "ASLIC") Ownable(msg.sender) {}

    function mintTo(address to, string calldata uri)
        external onlyOwner returns (uint256 tokenId)
    {
        tokenId = _nextId++;
        _safeMint(to, tokenId);
        _setTokenURI(tokenId, uri);
    }
}
