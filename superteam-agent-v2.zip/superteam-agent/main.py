"""Entrypoint.

Usage:
  python main.py register <agent-name>       one-time: prints apiKey + claimCode
  python main.py daemon                      scan loop (Ctrl-C to stop)
  python main.py scan                        single scan cycle
  python main.py approve <opp-id> <url>      resume paused task and submit
  python main.py reject <opp-id>             discard a paused task
  python main.py status                      show pipeline state
  python main.py ceo                         run one CEO strategy cycle (Claude API)
  python main.py products                    show product pipeline
  python main.py approve-product <sku>       approve + list a CEO-proposed product
  python main.py reject-product <sku>        discard a proposal
  python main.py storefront                  serve the x402 storefront
"""
from __future__ import annotations

import sys
import time

from src.config import load_settings
from src.db import Store
from src.orchestrator import Orchestrator
from src.superteam import SuperteamClient


def build() -> tuple[Orchestrator, Store]:
    cfg = load_settings()
    store = Store(cfg.database_path)
    client = SuperteamClient(cfg.superteam_base_url, cfg.superteam_api_key)
    return Orchestrator(cfg, store, client), store


def main() -> None:
    args = sys.argv[1:]
    cmd = args[0] if args else "daemon"

    if cmd == "register":
        import os
        name = args[1] if len(args) > 1 else os.getenv("AGENT_NAME", "my-agent")
        base = os.getenv("SUPERTEAM_BASE_URL", "https://superteam.fun")
        resp = SuperteamClient.register(base, name)
        print("Store these securely (the claimCode is how YOU get paid):")
        print(f"  SUPERTEAM_API_KEY={resp.get('apiKey')}")
        print(f"  claimCode={resp.get('claimCode')}   -> claim at {base}/earn/claim/<code>")
        print(f"  agentId={resp.get('agentId')}  username={resp.get('username')}")
        return

    orch, store = build()

    if cmd == "daemon":
        print("[daemon] starting scan loop")
        while True:
            try:
                n = orch.scan_and_dispatch()
                print(f"[daemon] cycle complete, dispatched={n}")
            except Exception as e:
                print(f"[daemon] cycle error: {e}")
            time.sleep(orch.cfg.scan_interval_s)

    elif cmd == "scan":
        print(f"dispatched={orch.scan_and_dispatch()}")

    elif cmd == "approve":
        if len(args) < 3:
            sys.exit("usage: python main.py approve <opp-id> <deliverable-url>")
        orch.approve_and_submit(args[1], args[2])
        print("resumed and submitted (check notifications / status)")

    elif cmd == "reject":
        if len(args) < 2:
            sys.exit("usage: python main.py reject <opp-id>")
        orch.reject(args[1])
        print("rejected")

    elif cmd == "status":
        for s in ("DISCOVERED", "TRIAGED", "IN_PROGRESS", "WAITING_HITL",
                  "SUBMITTED", "FAILED", "SKIPPED"):
            rows = store.get_by_status(s)
            if rows:
                print(f"\n{s} ({len(rows)}):")
                for r in rows[:10]:
                    print(f"  {r['id']}  ${r['reward_usd']:>7.0f}  {r['title'][:60]}")
    elif cmd == "ceo":
        from src.ceo import run_ceo_cycle
        report = run_ceo_cycle(orch.cfg, store)
        print("\n=== CEO ANALYSIS ===\n" + report.get("analysis", ""))
        tr = report.get("triage_recommendations", {})
        if tr:
            print(f"\nTriage rec: min_ev={tr.get('min_ev_score')} "
                  f"focus={tr.get('skill_focus')} — {tr.get('reason')}")
        props = report.get("accepted_skus", [])
        if props:
            print(f"\nProposed products (PENDING YOUR APPROVAL): {props}")
            print("Review with `python main.py products`, then approve-product <sku>.")
        else:
            print("\nNo viable products this cycle: "
                  + str(report.get("skip_reason", "")))

    elif cmd == "products":
        for s in ("PROPOSED", "LISTED", "REJECTED", "RETIRED"):
            rows = store.products_by_status(s)
            if rows:
                print(f"\n{s} ({len(rows)}):")
                for r in rows:
                    print(f"  {r['sku']}  ${float(r['price_usdc']):.2f}  "
                          f"nft={bool(r['license_nft'])}  {r['title'][:55]}")
                    if s == "PROPOSED":
                        print(f"      rationale: {r['ceo_rationale'][:120]}")

    elif cmd == "approve-product":
        if len(args) < 2:
            sys.exit("usage: python main.py approve-product <sku>")
        prod = store.get_product(args[1])
        if not prod:
            sys.exit("unknown sku")
        store.set_product_status(args[1], "LISTED")
        print(f"LISTED {args[1]} at ${float(prod['price_usdc']):.2f} USDC. "
              "Restart the storefront to pick up new routes.")

    elif cmd == "reject-product":
        if len(args) < 2:
            sys.exit("usage: python main.py reject-product <sku>")
        store.set_product_status(args[1], "REJECTED")
        print("rejected")

    elif cmd == "storefront":
        from src.storefront import serve
        serve(store)

    else:
        sys.exit(__doc__)


if __name__ == "__main__":
    main()
